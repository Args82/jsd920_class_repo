/////////////////////////////////////////////////////////////////////////////////////

Traitify's Careers Assessment

-- Description --
Personalize work-related sites and applications with Traitify’s Career Assessment. The Career deck offers developers rich data points including personality blend, types, traits and matching. Built for users including students, job-seekers, teams, human resources and leadership, Career data can be used to enrich experiences, drive engagement and build more productive teams and work spaces.

-- Great for -- 
Hiring, team building, retention, training, matching to majors, schools or jobs

-- Personality Types -- 
Action-Taker, Planner, Naturalist, Analyzer, Visionary, Mentor, Inventor

Need help? Email us via support@traitiy.com

/////////////////////////////////////////////////////////////////////////////////////